﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            OleDbConnection con = new OleDbConnection(@"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\sama\Desktop\DSS Practical\y.accdb");
            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter("Select * from DSS", con);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            button2.Visible = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        string[] s = { "A", "B", "C", "D", "E", "F" };
        private void button2_Click(object sender, EventArgs e)
        {
            for (int k = 0; k < s.Length; k++)
            {
                int count = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                        if (s[k] == dataGridView1.Rows[i].Cells[j].Value.ToString())
                            count++;
                }
                if (count >= 2)
                    dataGridView2.Rows.Add(s[k], count);
                button3.Visible = true;

            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            int count = 0;
            string it1 = " ", it2 = " ";
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                it1 = dataGridView2.Rows[i].Cells[0].Value.ToString();
                for (int j = i + 1; j < dataGridView2.Rows.Count - 1; j++)
                {
                    it2 = dataGridView2.Rows[j].Cells[0].Value.ToString();

                    for (int k = 0; k < dataGridView1.Rows.Count - 1; k++)
                    {
                        for (int n = 0; n < dataGridView1.ColumnCount; n++)
                        {
                            if (it1 == dataGridView1.Rows[k].Cells[n].Value.ToString())

                                for (int m = 0; m < dataGridView1.ColumnCount; m++)
                                {
                                    if (it2 == dataGridView1.Rows[k].Cells[m].Value.ToString())
                                        count++;


                                }

                        }

                    }
                    if (count >= 3)
                        dataGridView3.Rows.Add(it1 + " " + it2, count);
                    count = 0;
                    //button4.Visible = true;

                }

            }
        }

        //    private void button4_Click(object sender, EventArgs e)
        //    {

        //        int count = 0;
        //        string it1 = " ", it2 = " ", it3 = " ";
        //        //dataGridView4.Rows[0].Cells[0].Value = (dataGridView2.Rows[1].Cells[0].Value.ToString() + dataGridView2.Rows[1].Cells[1].Value.ToString() + dataGridView2.Rows[1].Cells[2].Value.ToString());

        //        //for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
        //        //{
        //        //    it1 = dataGridView3.Rows[i].Cells[0].Value.ToString();
        //        //    for (int j = 0; j < dataGridView3.Rows.Count - 1; j++)
        //        //    {
        //        //        it2 = dataGridView3.Rows[j].Cells[0].Value.ToString();

        //        //        for (int l = j + 1; l < dataGridView3.Rows.Count - 1; l++)

        //        //            it3 = dataGridView3.Rows[l].Cells[0].Value.ToString();

        //        //        for (int k = 0; k < dataGridView1.Rows.Count - 1; k++)
        //        //        {
        //        //            for (int n = 0; n < dataGridView1.ColumnCount; n++)
        //        //                if (it1 == dataGridView1.Rows[k].Cells[n].Value.ToString())

        //        //                    for (int m = 0; m < dataGridView1.ColumnCount; m++)
        //        //                        if (it2 == dataGridView1.Rows[k].Cells[m].Value.ToString())

        //        //                            for (int l = 0; l < dataGridView1.ColumnCount; l++)
        //        //                                if (it3 == dataGridView1.Rows[k].Cells[l].Value.ToString())
        //        //                                    count++;
        //        //        }
        //        dataGridView4.Rows.Add((dataGridView3.Rows[0].Cells[0].Value.ToString() + " " + dataGridView2.Rows[2].Cells[0].Value.ToString()) , count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[0].Cells[0].Value.ToString() + " " + dataGridView2.Rows[3].Cells[0].Value.ToString()), count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[0].Cells[0].Value.ToString() + " " + dataGridView2.Rows[4].Cells[0].Value.ToString()), count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[1].Cells[0].Value.ToString() + " " + dataGridView2.Rows[3].Cells[0].Value.ToString()), count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[1].Cells[0].Value.ToString() + " " + dataGridView2.Rows[4].Cells[0].Value.ToString()), count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[2].Cells[0].Value.ToString() + " " + dataGridView2.Rows[4].Cells[0].Value.ToString()), count);
        //        dataGridView4.Rows.Add((dataGridView3.Rows[4].Cells[0].Value.ToString() + " " + dataGridView2.Rows[4].Cells[0].Value.ToString()), count);
        //        //        count = 0;


        //        //    }
        //        //}



        //    }
        //}
    }
}
